/**
 * @(#)ILaserParticleCounterScheduleService.java	09/24/2015
 * 
 * Copyright (c) 2015 app118.cn.All rights reserved.
 * Created by 2015-09-24
 */
package cn.app118.service.task;

/**
 * 定时任务
 * 
 * @author wRitchie
 *
 */
public interface ILaserParticleCounterScheduleService {
	//自动采集心知天气信息
	public void grabWeatherInfo(); 
}
